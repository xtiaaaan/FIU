package mpg_test;

/*
Before submitting your project, delete the line above:
package mpg_test
 */


import java.util.Scanner;

/**
 *
 * @author dfreer
 */
public class Mpg_test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         
    }
    
}
